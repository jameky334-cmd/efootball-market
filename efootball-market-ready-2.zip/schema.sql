CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 display_name TEXT,
 role TEXT NOT NULL DEFAULT 'buyer' CHECK(role IN ('buyer','seller','admin')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS listings (
 id BIGSERIAL PRIMARY KEY,
 seller_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 title TEXT NOT NULL,
 description TEXT DEFAULT '',
 price NUMERIC(12,2) NOT NULL CHECK(price >= 0),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','reserved','sold','hidden')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS orders (
 id BIGSERIAL PRIMARY KEY,
 listing_id BIGINT REFERENCES listings(id) ON DELETE SET NULL,
 buyer_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 seller_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 amount NUMERIC(12,2) NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid_review','confirmed','completed','cancelled','disputed')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS listings_status_created_idx ON listings(status,created_at DESC);
CREATE INDEX IF NOT EXISTS orders_buyer_idx ON orders(buyer_id,created_at DESC);
