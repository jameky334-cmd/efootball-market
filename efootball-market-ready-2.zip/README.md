# eFootball Market TH

ตลาดซื้อขายไอดี eFootball ภาษาไทย รองรับหน้าเว็บแบบ responsive และมี Express API สำหรับต่อ PostgreSQL

## รันในเครื่อง
```bash
npm install
npm start
```
เปิด `http://localhost:10000`

## PostgreSQL
ตั้งค่า `DATABASE_URL` แล้วรัน `schema.sql` กับฐานข้อมูล

## Render
โปรเจกต์มี `render.yaml` สำหรับ Web Service + PostgreSQL โดยตั้ง health check ที่ `/api/health`

> ระบบตัวอย่างยังไม่ควรใช้รับรหัสผ่านหรือข้อมูลบัตรจริง และการซื้อขายบัญชีอาจอยู่ภายใต้ข้อกำหนดของผู้ให้บริการเกม ควรตรวจสอบเงื่อนไขที่เกี่ยวข้องก่อนเปิดใช้งานเชิงพาณิชย์
