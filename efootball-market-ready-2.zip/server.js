const express = require('express');
const path = require('path');
const { Pool } = require('pg');
const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(__dirname));
const pool = process.env.DATABASE_URL ? new Pool({connectionString:process.env.DATABASE_URL, ssl:{rejectUnauthorized:false}}) : null;
async function initDb(){ if(!pool) return; const fs=require('fs'); const sql=fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'); await pool.query(sql); }
app.get('/api/health', async (req,res)=>{
  let db='not_configured';
  if(pool){ try{ await pool.query('SELECT 1'); db='ok'; }catch(e){ db='error'; } }
  res.json({ok:true,service:'efootball-market',database:db,time:new Date().toISOString()});
});
app.get('/api/listings', async (req,res)=>{
  if(!pool) return res.json({source:'demo',items:[]});
  try { const r=await pool.query('SELECT id,title,price,description,status,created_at FROM listings WHERE status=\'active\' ORDER BY created_at DESC LIMIT 100'); res.json({source:'postgres',items:r.rows}); }
  catch(e){ res.status(500).json({error:'database_error'}); }
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));
const port=process.env.PORT||10000;
app.listen(port,'0.0.0.0',async()=>{ try{await initDb(); console.log('Database schema ready');}catch(e){console.error('Database init failed:',e.message);} console.log(`eFootball Market listening on ${port}`); });
