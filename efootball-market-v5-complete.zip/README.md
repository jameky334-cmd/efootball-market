# eFootball Market v5.0.0

ระบบ Marketplace สำหรับซื้อขายไอดี eFootball

## Backend
- Node.js + Express
- PostgreSQL
- JWT login
- bcrypt password hashing
- Buyer / Seller / Admin
- Admin user management
- Listings
- Orders
- Generic payment webhook
- Encrypted delivery data (AES-256-GCM)
- Audit logs
- Rate limiting

## Render Environment Variables
ตั้งค่าที่ API service:
- DATABASE_URL
- JWT_SECRET
- FRONTEND_ORIGIN=https://efootball-market.onrender.com
- NODE_ENV=production
- PAYMENT_WEBHOOK_SECRET
- DELIVERY_ENCRYPTION_KEY (64 hex characters)
- ADMIN_BOOTSTRAP_SECRET

ห้ามนำค่า secret ไปใส่ใน GitHub

## Deploy API
Build: npm install
Start: npm start
Health: /health

## Deploy frontend
ใช้ index.html เป็น Static Site
หรือเปลี่ยน Build Command เป็น:
cp index.html index.html

## เปิดสิทธิ์ Admin ครั้งแรก
1. สมัครสมาชิกผ่านเว็บ
2. ล็อกอินบัญชีนั้น
3. เปิด Developer/Bootstrap endpoint ผ่านหน้าเว็บตามที่พัฒนาต่อ หรือเรียก:
POST /api/admin/bootstrap
Authorization: Bearer <token>
JSON: {"secret":"ค่า ADMIN_BOOTSTRAP_SECRET"}

ระบบจะยอมให้ bootstrap ได้เฉพาะเมื่อยังไม่มี admin อยู่

## หมายเหตุการชำระเงิน
/api/payments/webhook เป็น integration point เท่านั้น
ยังไม่ใช่การเชื่อม TrueMoney โดยตรง ต้องใช้ API/Payment Gateway ที่ได้รับอนุญาตและตรวจสอบ webhook ตามเอกสารผู้ให้บริการก่อนใช้งานจริง
