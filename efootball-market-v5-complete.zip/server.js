import express from "express";
import cors from "cors";
import pg from "pg";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";

const { Pool } = pg;
const app = express();

const VERSION = "5.0.0";
const PORT = Number(process.env.PORT || 10000);
const DATABASE_URL = process.env.DATABASE_URL;
const JWT_SECRET = process.env.JWT_SECRET;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "";
const NODE_ENV = process.env.NODE_ENV || "production";
const PAYMENT_WEBHOOK_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || "";
const DELIVERY_ENCRYPTION_KEY = process.env.DELIVERY_ENCRYPTION_KEY || "";
const ADMIN_BOOTSTRAP_SECRET = process.env.ADMIN_BOOTSTRAP_SECRET || "";

if (!DATABASE_URL) throw new Error("DATABASE_URL is missing");
if (!JWT_SECRET) throw new Error("JWT_SECRET is missing");

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

const allowedOrigins = FRONTEND_ORIGIN.split(",").map(x => x.trim()).filter(Boolean);
app.use(cors({
  origin(origin, cb) {
    if (!origin) return cb(null, true);
    if (allowedOrigins.includes("*") || allowedOrigins.includes(origin)) return cb(null, true);
    if (NODE_ENV !== "production" && /^http:\/\/(localhost|127\.0\.0\.1):/.test(origin)) return cb(null, true);
    return cb(new Error("CORS origin not allowed"));
  },
  methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Webhook-Secret"]
}));

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});

const limiter = new Map();
function rateLimit(windowMs = 60000, max = 60) {
  return (req, res, next) => {
    const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown").split(",")[0].trim();
    const key = `${req.path}:${ip}`;
    const now = Date.now();
    const old = limiter.get(key);
    if (!old || now - old.start >= windowMs) {
      limiter.set(key, { start: now, count: 1 });
      return next();
    }
    old.count++;
    if (old.count > max) return res.status(429).json({ error: "Too many requests" });
    next();
  };
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of limiter) if (now - v.start > 10 * 60 * 1000) limiter.delete(k);
}, 5 * 60 * 1000).unref();

const clean = (v, n = 500) => String(v ?? "").trim().slice(0, n);
const validEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const validPrice = v => Number.isFinite(Number(v)) && Number(v) > 0 && Number(v) <= 100000000;
const price = v => Number(Number(v).toFixed(2));

function deliveryKey() {
  return /^[0-9a-fA-F]{64}$/.test(DELIVERY_ENCRYPTION_KEY)
    ? Buffer.from(DELIVERY_ENCRYPTION_KEY, "hex")
    : null;
}
function encryptDelivery(value) {
  const key = deliveryKey();
  if (!key) throw new Error("Secure delivery is not configured");
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", key, iv);
  const data = Buffer.concat([c.update(String(value), "utf8"), c.final()]);
  return `${iv.toString("base64")}.${c.getAuthTag().toString("base64")}.${data.toString("base64")}`;
}
function decryptDelivery(value) {
  const key = deliveryKey();
  if (!key) throw new Error("Secure delivery is not configured");
  const [iv, tag, data] = String(value).split(".");
  if (!iv || !tag || !data) throw new Error("Invalid delivery data");
  const d = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
  d.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([d.update(Buffer.from(data, "base64")), d.final()]).toString("utf8");
}

const publicUser = u => ({ id: u.id, email: u.email, role: u.role });
const sign = u => jwt.sign({ id: u.id }, JWT_SECRET, { expiresIn: "7d" });

async function auth(req, res, next) {
  try {
    const h = String(req.headers.authorization || "");
    if (!h.startsWith("Bearer ")) return res.status(401).json({ error: "Authentication required" });
    const decoded = jwt.verify(h.slice(7), JWT_SECRET);
    const r = await pool.query("SELECT id,email,role FROM users WHERE id=$1 LIMIT 1", [decoded.id]);
    if (!r.rowCount) return res.status(401).json({ error: "User not found" });
    req.user = r.rows[0];
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}
function role(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "Authentication required" });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: "Permission denied" });
    next();
  };
}
async function audit(client, userId, action, entityType, entityId, details = {}) {
  await client.query(
    `INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details)
     VALUES($1,$2,$3,$4,$5::jsonb)`,
    [userId || null, action, entityType, entityId || null, JSON.stringify(details)]
  );
}

async function initDb() {
  const c = await pool.connect();
  try {
    await c.query("BEGIN");
    await c.query(`
      CREATE TABLE IF NOT EXISTS users(
        id BIGSERIAL PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'buyer'
          CHECK(role IN('buyer','seller','admin')),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS listings(
        id BIGSERIAL PRIMARY KEY,
        seller_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        price NUMERIC(12,2) NOT NULL CHECK(price > 0),
        account_data_encrypted TEXT,
        status TEXT NOT NULL DEFAULT 'active'
          CHECK(status IN('active','sold','cancelled')),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS orders(
        id BIGSERIAL PRIMARY KEY,
        buyer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        listing_id BIGINT NOT NULL REFERENCES listings(id) ON DELETE RESTRICT,
        price NUMERIC(12,2) NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending'
          CHECK(status IN('pending','paid','completed','cancelled')),
        payment_provider TEXT,
        payment_ref TEXT,
        payment_status TEXT NOT NULL DEFAULT 'pending'
          CHECK(payment_status IN('pending','paid','failed','cancelled')),
        paid_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS audit_logs(
        id BIGSERIAL PRIMARY KEY,
        user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id BIGINT,
        details JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status);
      CREATE INDEX IF NOT EXISTS idx_listings_seller ON listings(seller_id);
      CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
      CREATE INDEX IF NOT EXISTS idx_orders_listing ON orders(listing_id);
      CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
      CREATE UNIQUE INDEX IF NOT EXISTS idx_open_order_listing
        ON orders(listing_id) WHERE status IN('pending','paid');
      CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_ref
        ON orders(payment_ref) WHERE payment_ref IS NOT NULL;
    `);
    await c.query("COMMIT");
  } catch (e) {
    await c.query("ROLLBACK");
    throw e;
  } finally {
    c.release();
  }
}

app.get("/", (req,res) => res.json({ name:"eFootball Market API", version:VERSION, status:"ok" }));
app.get("/health", (req,res) => res.json({
  ok:true, version:VERSION,
  database:Boolean(DATABASE_URL),
  webhook:Boolean(PAYMENT_WEBHOOK_SECRET),
  secure_delivery:Boolean(deliveryKey())
}));

app.post("/api/auth/register", rateLimit(60000,10), async (req,res,next) => {
  try {
    const email = clean(req.body?.email,200).toLowerCase();
    const password = String(req.body?.password || "");
    if (!validEmail(email)) return res.status(400).json({error:"Invalid email address"});
    if (password.length < 8 || password.length > 128) return res.status(400).json({error:"Password must be 8-128 characters"});
    const exists = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
    if (exists.rowCount) return res.status(409).json({error:"Email already registered"});
    const hash = await bcrypt.hash(password,12);
    const r = await pool.query(
      `INSERT INTO users(email,password_hash,role) VALUES($1,$2,'buyer') RETURNING id,email,role`,
      [email,hash]
    );
    res.status(201).json({user:publicUser(r.rows[0]),token:sign(r.rows[0])});
  } catch(e) { next(e); }
});

app.post("/api/auth/login", rateLimit(60000,10), async (req,res,next) => {
  try {
    const email = clean(req.body?.email,200).toLowerCase();
    const password = String(req.body?.password || "");
    const r = await pool.query("SELECT id,email,password_hash,role FROM users WHERE email=$1", [email]);
    if (!r.rowCount || !(await bcrypt.compare(password,r.rows[0].password_hash)))
      return res.status(401).json({error:"Invalid email or password"});
    res.json({user:publicUser(r.rows[0]),token:sign(r.rows[0])});
  } catch(e) { next(e); }
});

app.get("/api/me", auth, (req,res) => res.json({user:publicUser(req.user)}));

app.get("/api/listings", async (req,res,next) => {
  try {
    const r = await pool.query(`
      SELECT l.id,l.title,l.description,l.price,l.status,l.created_at,l.seller_id,
             u.email AS seller_email
      FROM listings l JOIN users u ON u.id=l.seller_id
      WHERE l.status='active'
      ORDER BY l.created_at DESC LIMIT 100
    `);
    res.json({listings:r.rows});
  } catch(e) { next(e); }
});

app.post("/api/listings", auth, role("seller","admin"), async (req,res,next) => {
  try {
    const title=clean(req.body?.title,150), description=clean(req.body?.description,3000);
    const amount=Number(req.body?.price), accountData=clean(req.body?.account_data,10000);
    if (!title) return res.status(400).json({error:"Title is required"});
    if (!validPrice(amount)) return res.status(400).json({error:"Invalid price"});
    if (accountData && !deliveryKey()) return res.status(503).json({error:"Secure delivery is not configured"});
    const encrypted=accountData ? encryptDelivery(accountData) : null;
    const r=await pool.query(`
      INSERT INTO listings(seller_id,title,description,price,account_data_encrypted)
      VALUES($1,$2,$3,$4,$5)
      RETURNING id,seller_id,title,description,price,status,created_at
    `,[req.user.id,title,description,price(amount),encrypted]);
    res.status(201).json({listing:r.rows[0]});
  } catch(e) { next(e); }
});

app.get("/api/my-listings",auth,role("seller","admin"),async(req,res,next)=>{
  try {
    const r=await pool.query(`
      SELECT id,seller_id,title,description,price,status,created_at
      FROM listings WHERE seller_id=$1 ORDER BY created_at DESC
    `,[req.user.id]);
    res.json({listings:r.rows});
  } catch(e){next(e);}
});

app.post("/api/orders",auth,async(req,res,next)=>{
  const c=await pool.connect();
  try {
    const listingId=Number(req.body?.listing_id);
    if(!Number.isInteger(listingId)||listingId<=0) return res.status(400).json({error:"Invalid listing id"});
    await c.query("BEGIN");
    const l=await c.query("SELECT * FROM listings WHERE id=$1 FOR UPDATE",[listingId]);
    if(!l.rowCount) { await c.query("ROLLBACK"); return res.status(404).json({error:"Listing not found"}); }
    const listing=l.rows[0];
    if(listing.status!=="active") { await c.query("ROLLBACK"); return res.status(409).json({error:"Listing is not available"}); }
    if(Number(listing.seller_id)===Number(req.user.id)) { await c.query("ROLLBACK"); return res.status(400).json({error:"You cannot buy your own listing"}); }
    const r=await c.query(`
      INSERT INTO orders(buyer_id,listing_id,price)
      VALUES($1,$2,$3)
      RETURNING id,buyer_id,listing_id,price,status,payment_status,created_at
    `,[req.user.id,listingId,listing.price]);
    await audit(c,req.user.id,"order.created","order",r.rows[0].id,{listing_id:listingId});
    await c.query("COMMIT");
    res.status(201).json({order:r.rows[0]});
  } catch(e) {
    try{await c.query("ROLLBACK")}catch{}
    if(e.code==="23505") return res.status(409).json({error:"This listing already has an open order"});
    next(e);
  } finally { c.release(); }
});

app.get("/api/orders",auth,async(req,res,next)=>{
  try {
    let sql=`
      SELECT o.id,o.buyer_id,o.listing_id,o.price,o.status,
             o.payment_provider,o.payment_ref,o.payment_status,o.paid_at,o.created_at,
             l.title,l.seller_id
      FROM orders o JOIN listings l ON l.id=o.listing_id`;
    const params=[];
    if(req.user.role==="admin") {}
    else if(req.user.role==="seller") { sql+=" WHERE l.seller_id=$1"; params.push(req.user.id); }
    else { sql+=" WHERE o.buyer_id=$1"; params.push(req.user.id); }
    sql+=" ORDER BY o.created_at DESC LIMIT 100";
    const r=await pool.query(sql,params);
    res.json({orders:r.rows});
  } catch(e){next(e);}
});

app.get("/api/orders/:id",auth,async(req,res,next)=>{
  try {
    const id=Number(req.params.id);
    const r=await pool.query(`
      SELECT o.*,l.title,l.description,l.seller_id
      FROM orders o JOIN listings l ON l.id=o.listing_id WHERE o.id=$1
    `,[id]);
    if(!r.rowCount) return res.status(404).json({error:"Order not found"});
    const o=r.rows[0];
    const allowed=req.user.role==="admin"||Number(o.buyer_id)===Number(req.user.id)||
      (req.user.role==="seller"&&Number(o.seller_id)===Number(req.user.id));
    if(!allowed) return res.status(403).json({error:"Permission denied"});
    res.json({order:o});
  } catch(e){next(e);}
});

async function markPaid({orderId,paymentRef,amount,provider}) {
  const c=await pool.connect();
  try {
    await c.query("BEGIN");
    const r=await c.query("SELECT * FROM orders WHERE id=$1 FOR UPDATE",[orderId]);
    if(!r.rowCount) throw new Error("Order not found");
    const o=r.rows[0];
    if(price(amount)!==price(o.price)) throw new Error("Payment amount does not match order price");
    if(o.payment_status==="paid"){await c.query("COMMIT");return o;}
    if(o.status!=="pending"||o.payment_status!=="pending") throw new Error("Order is not payable");
    const u=await c.query(`
      UPDATE orders SET payment_provider=$1,payment_ref=$2,payment_status='paid',paid_at=NOW(),status='paid'
      WHERE id=$3 AND status='pending' AND payment_status='pending'
      RETURNING *
    `,[provider,paymentRef,orderId]);
    if(!u.rowCount) throw new Error("Payment confirmation failed");
    await audit(c,null,"payment.confirmed","order",orderId,{provider,ref:paymentRef});
    await c.query("COMMIT");
    return u.rows[0];
  } catch(e){try{await c.query("ROLLBACK")}catch{};throw e;}
  finally{c.release();}
}

app.post("/api/payments/webhook",rateLimit(60000,120),async(req,res,next)=>{
  try {
    if(!PAYMENT_WEBHOOK_SECRET) return res.status(503).json({error:"Payment webhook is not configured"});
    const supplied=Buffer.from(String(req.headers["x-webhook-secret"]||""));
    const expected=Buffer.from(PAYMENT_WEBHOOK_SECRET);
    if(supplied.length!==expected.length||!crypto.timingSafeEqual(supplied,expected))
      return res.status(401).json({error:"Invalid webhook secret"});
    const orderId=Number(req.body?.order_id), paymentRef=clean(req.body?.payment_ref,200);
    const amount=Number(req.body?.amount), provider=clean(req.body?.provider||"gateway",50);
    if(!Number.isInteger(orderId)||orderId<=0||!paymentRef||!validPrice(amount))
      return res.status(400).json({error:"Invalid payment webhook payload"});
    const o=await markPaid({orderId,paymentRef,amount,provider});
    res.json({ok:true,order_id:o.id,status:o.status,payment_status:o.payment_status});
  } catch(e) {
    if(e.code==="23505") return res.status(409).json({error:"Payment reference already used"});
    if(["Order not found","Payment amount does not match order price","Order is not payable","Payment confirmation failed"].includes(e.message))
      return res.status(409).json({error:e.message});
    next(e);
  }
});

app.get("/api/orders/:id/delivery",auth,async(req,res,next)=>{
  try {
    const id=Number(req.params.id);
    const r=await pool.query(`
      SELECT o.id,o.buyer_id,o.status,o.payment_status,l.id AS listing_id,l.account_data_encrypted
      FROM orders o JOIN listings l ON l.id=o.listing_id WHERE o.id=$1
    `,[id]);
    if(!r.rowCount) return res.status(404).json({error:"Order not found"});
    const o=r.rows[0];
    if(req.user.role!=="admin"&&Number(o.buyer_id)!==Number(req.user.id))
      return res.status(403).json({error:"Only the buyer can receive delivery"});
    if(o.payment_status!=="paid"||!["paid","completed"].includes(o.status))
      return res.status(409).json({error:"Payment must be confirmed before delivery"});
    if(!o.account_data_encrypted) return res.status(404).json({error:"Secure account delivery data is not available"});
    res.json({order_id:o.id,listing_id:o.listing_id,account_data:decryptDelivery(o.account_data_encrypted)});
  } catch(e){next(e);}
});

app.patch("/api/orders/:id/status",auth,role("seller","admin"),async(req,res,next)=>{
  const c=await pool.connect();
  try {
    const id=Number(req.params.id), newStatus=clean(req.body?.status,20);
    if(!Number.isInteger(id)||!["completed","cancelled"].includes(newStatus))
      return res.status(400).json({error:"Invalid status"});
    await c.query("BEGIN");
    const r=await c.query(`
      SELECT o.*,l.seller_id,l.status AS listing_status
      FROM orders o JOIN listings l ON l.id=o.listing_id WHERE o.id=$1 FOR UPDATE
    `,[id]);
    if(!r.rowCount){await c.query("ROLLBACK");return res.status(404).json({error:"Order not found"});}
    const o=r.rows[0];
    if(req.user.role!=="admin"&&Number(o.seller_id)!==Number(req.user.id)){
      await c.query("ROLLBACK");return res.status(403).json({error:"Permission denied"});
    }
    if(newStatus==="completed"){
      if(o.status!=="paid"||o.payment_status!=="paid"){
        await c.query("ROLLBACK");return res.status(409).json({error:"Only paid orders can be completed"});
      }
      const sold=await c.query("UPDATE listings SET status='sold' WHERE id=$1 AND status='active' RETURNING id",[o.listing_id]);
      if(!sold.rowCount){await c.query("ROLLBACK");return res.status(409).json({error:"Listing is no longer active"});}
    } else {
      if(!["pending","paid"].includes(o.status)){
        await c.query("ROLLBACK");return res.status(409).json({error:"Order cannot be cancelled"});
      }
      await c.query("UPDATE listings SET status='active' WHERE id=$1 AND status<>'sold'",[o.listing_id]);
      if(o.payment_status!=="paid") await c.query("UPDATE orders SET payment_status='cancelled' WHERE id=$1",[id]);
    }
    const u=await c.query("UPDATE orders SET status=$1 WHERE id=$2 RETURNING *",[newStatus,id]);
    await audit(c,req.user.id,`order.${newStatus}`,"order",id,{listing_id:o.listing_id});
    await c.query("COMMIT");
    res.json({order:u.rows[0]});
  } catch(e){try{await c.query("ROLLBACK")}catch{};next(e);}
  finally{c.release();}
});

app.post("/api/admin/bootstrap",auth,rateLimit(60000,5),async(req,res,next)=>{
  try {
    if(!ADMIN_BOOTSTRAP_SECRET) return res.status(503).json({error:"Admin bootstrap is not configured"});
    if(req.user.role==="admin") return res.json({ok:true,user:publicUser(req.user)});
    const supplied=Buffer.from(String(req.body?.secret||"")), expected=Buffer.from(ADMIN_BOOTSTRAP_SECRET);
    if(supplied.length!==expected.length||!crypto.timingSafeEqual(supplied,expected))
      return res.status(401).json({error:"Invalid admin bootstrap secret"});
    const a=await pool.query("SELECT id FROM users WHERE role='admin' LIMIT 1");
    if(a.rowCount) return res.status(409).json({error:"An admin account already exists"});
    const r=await pool.query("UPDATE users SET role='admin' WHERE id=$1 RETURNING id,email,role",[req.user.id]);
    res.json({ok:true,user:publicUser(r.rows[0])});
  } catch(e){next(e);}
});

app.get("/api/admin/users",auth,role("admin"),async(req,res,next)=>{
  try {
    const r=await pool.query("SELECT id,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 500");
    res.json({users:r.rows});
  } catch(e){next(e);}
});

app.patch("/api/admin/users/:id/role",auth,role("admin"),async(req,res,next)=>{
  const c=await pool.connect();
  try {
    const id=Number(req.params.id), newRole=clean(req.body?.role,20);
    if(!Number.isInteger(id)||!["buyer","seller","admin"].includes(newRole))
      return res.status(400).json({error:"Invalid user id or role"});
    if(id===Number(req.user.id)&&newRole!=="admin")
      return res.status(400).json({error:"You cannot remove your own admin role"});
    await c.query("BEGIN");
    const r=await c.query("UPDATE users SET role=$1 WHERE id=$2 RETURNING id,email,role,created_at",[newRole,id]);
    if(!r.rowCount){await c.query("ROLLBACK");return res.status(404).json({error:"User not found"});}
    await audit(c,req.user.id,"user.role_changed","user",id,{role:newRole});
    await c.query("COMMIT");
    res.json({user:r.rows[0]});
  } catch(e){try{await c.query("ROLLBACK")}catch{};next(e);}
  finally{c.release();}
});

app.get("/api/admin/audit-logs",auth,role("admin"),async(req,res,next)=>{
  try {
    const r=await pool.query(`
      SELECT id,user_id,action,entity_type,entity_id,details,created_at
      FROM audit_logs ORDER BY created_at DESC LIMIT 500
    `);
    res.json({logs:r.rows});
  } catch(e){next(e);}
});

app.get("/api/stats",auth,role("seller","admin"),async(req,res,next)=>{
  try {
    let r;
    if(req.user.role==="admin"){
      r=await pool.query(`
        SELECT
          (SELECT COUNT(*) FROM users) AS users,
          (SELECT COUNT(*) FROM listings) AS listings,
          (SELECT COUNT(*) FROM listings WHERE status='active') AS active_listings,
          (SELECT COUNT(*) FROM orders) AS orders,
          (SELECT COUNT(*) FROM orders WHERE status='completed') AS completed_orders,
          (SELECT COALESCE(SUM(price),0) FROM orders WHERE status='completed') AS completed_revenue
      `);
    } else {
      r=await pool.query(`
        SELECT
          (SELECT COUNT(*) FROM listings WHERE seller_id=$1) AS listings,
          (SELECT COUNT(*) FROM listings WHERE seller_id=$1 AND status='active') AS active_listings,
          (SELECT COUNT(*) FROM orders o JOIN listings l ON l.id=o.listing_id WHERE l.seller_id=$1) AS orders,
          (SELECT COUNT(*) FROM orders o JOIN listings l ON l.id=o.listing_id WHERE l.seller_id=$1 AND o.status='completed') AS completed_orders,
          (SELECT COALESCE(SUM(o.price),0) FROM orders o JOIN listings l ON l.id=o.listing_id WHERE l.seller_id=$1 AND o.status='completed') AS completed_revenue
      `,[req.user.id]);
    }
    res.json({stats:r.rows[0]});
  } catch(e){next(e);}
});

app.use((req,res)=>res.status(404).json({error:"Route not found"}));
app.use((err,req,res,next)=>{
  console.error(err);
  if(err.message==="CORS origin not allowed") return res.status(403).json({error:err.message});
  if(err.code==="23505") return res.status(409).json({error:"Duplicate record"});
  res.status(500).json({error:"Internal server error"});
});

async function start(){
  await initDb();
  const server=app.listen(PORT,()=>console.log(`eFootball Market API v${VERSION} on ${PORT}`));
  const shutdown=async()=>{server.close(async()=>{await pool.end();process.exit(0);});};
  process.on("SIGTERM",shutdown);
  process.on("SIGINT",shutdown);
}
start().catch(async e=>{console.error("Startup failed",e);await pool.end();process.exit(1);});
