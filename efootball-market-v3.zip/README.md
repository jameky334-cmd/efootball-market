# eFootball Market TH

Marketplace frontend + Express/PostgreSQL API.

## Production

- Frontend: `https://efootball-market.onrender.com`
- API: `https://efootball-market-api.onrender.com`
- Database: Render PostgreSQL

### API environment variables

- `DATABASE_URL` — Render PostgreSQL connection string
- `FRONTEND_ORIGIN` — production frontend origin
- `NODE_ENV=production`

Secrets must be configured in Render Environment, not committed to Git. Render supports linking a PostgreSQL connection string through `fromDatabase` in a Blueprint. See Render documentation.

## Run locally

```bash
npm install
npm start
```

## Main API

- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/auth/csrf`
- `GET /api/listings`
- `POST /api/listings` (seller/admin)
- `GET /api/orders` (authenticated)
- `POST /api/orders` (authenticated)
- `PATCH /api/orders/:id/status`
