# eFootball Market TH

Marketplace frontend + Express/PostgreSQL API.

## Production

- Frontend: `https://efootball-market.onrender.com`
- API: `https://efootball-market-api.onrender.com`
- Database: Render PostgreSQL

### API environment variables

- `DATABASE_URL` — Render PostgreSQL connection string
- `FRONTEND_ORIGIN` — production frontend origin
- `NODE_ENV=production`

Secrets must be configured in Render Environment, not committed to Git. Render supports linking a PostgreSQL connection string through `fromDatabase` in a Blueprint. See Render documentation.

## Run locally

```bash
npm install
npm start
```

## Main API

- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/auth/csrf`
- `GET /api/listings`
- `POST /api/listings` (seller/admin)
- `GET /api/orders` (authenticated)
- `POST /api/orders` (authenticated)
- `PATCH /api/orders/:id/status`


## V4 fixes included
- Secure cookie-based sessions instead of JWT fallback secrets
- CSRF protection for state-changing requests
- Rate limiting on authentication and write endpoints
- Seller/admin authorization for listing creation
- Transaction + row locking for order creation
- Prevent buying your own listing
- Prevent multiple pending/paid orders for the same listing
- Database-backed health check
- Frontend API defaults to the deployed Render API and sends credentials

## Required Render settings
Set `DATABASE_URL` to the Internal Database URL from the Render PostgreSQL service. Keep this value secret. Also set `FRONTEND_ORIGIN=https://efootball-market.onrender.com`.
