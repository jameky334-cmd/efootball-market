import express from 'express';
import cors from 'cors';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';

const { Pool } = pg;
const app = express();

const PORT = Number(process.env.PORT || 10000);
const DATABASE_URL = process.env.DATABASE_URL;
const SESSION_TTL_DAYS = 7;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'https://efootball-market.onrender.com';

if (!DATABASE_URL) {
  console.error('Missing DATABASE_URL environment variable.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use(cors({
  origin: FRONTEND_ORIGIN,
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'X-CSRF-Token'],
}));

app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());

app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (process.env.NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'too many authentication attempts; try again later' },
});

const writeLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'too many requests; try again later' },
});

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function setSessionCookie(res, token) {
  res.cookie('__Host-Session', token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_TTL_DAYS * 24 * 60 * 60 * 1000,
  });
}

function clearSessionCookie(res) {
  res.clearCookie('__Host-Session', {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
  });
}

function requireCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const expected = req.cookies?.['XSRF-TOKEN'];
  const supplied = req.get('X-CSRF-Token');
  if (!expected || !supplied || expected.length !== supplied.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(supplied))) {
    return res.status(403).json({ error: 'csrf validation failed' });
  }
  next();
}

async function auth(req, res, next) {
  try {
    const token = req.cookies?.['__Host-Session'];
    if (!token) return res.status(401).json({ error: 'unauthorized' });
    const result = await pool.query(
      `SELECT s.id AS session_id, u.id, u.email, u.role, u.created_at
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = $1 AND s.expires_at > now()`,
      [sha256(token)]
    );
    if (!result.rowCount) return res.status(401).json({ error: 'unauthorized' });
    req.user = result.rows[0];
    req.sessionId = result.rows[0].session_id;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    return res.status(401).json({ error: 'unauthorized' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'forbidden' });
    }
    next();
  };
}

async function createSession(userId) {
  const token = randomToken(32);
  await pool.query(
    `INSERT INTO sessions(user_id, token_hash, expires_at)
     VALUES($1, $2, now() + ($3 * interval '1 day'))`,
    [userId, sha256(token), SESSION_TTL_DAYS]
  );
  return token;
}

async function initDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'buyer' CHECK (role IN ('buyer', 'seller', 'admin')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT UNIQUE NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS listings (
      id BIGSERIAL PRIMARY KEY,
      seller_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      price NUMERIC(12,2) NOT NULL CHECK (price > 0),
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'sold', 'cancelled')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      listing_id BIGINT NOT NULL REFERENCES listings(id) ON DELETE RESTRICT,
      buyer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'completed', 'cancelled')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE INDEX IF NOT EXISTS idx_listings_status_created ON listings(status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE UNIQUE INDEX IF NOT EXISTS uq_active_order_per_listing
      ON orders(listing_id) WHERE status IN ('pending', 'paid');
  `);

  await pool.query(`DELETE FROM sessions WHERE expires_at <= now()`);
  setInterval(() => {
    pool.query('DELETE FROM sessions WHERE expires_at <= now()').catch((error) => console.error('Session cleanup error:', error));
  }, 60 * 60 * 1000).unref();
}

app.get('/', (_req, res) => {
  res.json({ ok: true, service: 'efootball-market-api', health: '/api/health' });
});

app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, service: 'efootball-market-api', database: 'ok' });
  } catch (error) {
    console.error('Health check failed:', error);
    res.status(503).json({ ok: false, error: 'database unavailable' });
  }
});

app.get('/api/auth/me', auth, (req, res) => {
  res.json({ user: req.user });
});

app.get('/api/auth/csrf', (_req, res) => {
  const token = randomToken(24);
  res.cookie('XSRF-TOKEN', token, {
    httpOnly: false,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 1000,
  });
  res.json({ ok: true });
});

app.post('/api/auth/register', authLimiter, async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    const role = req.body?.role === 'seller' ? 'seller' : 'buyer';

    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'valid email required' });
    if (password.length < 8) return res.status(400).json({ error: 'password must be at least 8 characters' });

    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO users(email, password_hash, role) VALUES($1, $2, $3)
       RETURNING id, email, role, created_at`,
      [email, passwordHash, role]
    );

    const user = result.rows[0];
    const token = await createSession(user.id);
    setSessionCookie(res, token);
    res.status(201).json({ user });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'email already exists' });
    console.error('Register error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    const result = await pool.query(
      'SELECT id, email, password_hash, role, created_at FROM users WHERE email = $1',
      [email]
    );
    if (!result.rowCount || !(await bcrypt.compare(password, result.rows[0].password_hash))) {
      return res.status(401).json({ error: 'invalid credentials' });
    }
    const row = result.rows[0];
    const user = { id: row.id, email: row.email, role: row.role, created_at: row.created_at };
    const token = await createSession(user.id);
    setSessionCookie(res, token);
    res.json({ user });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/auth/logout', auth, async (req, res) => {
  try {
    await pool.query('DELETE FROM sessions WHERE id = $1', [req.sessionId]);
  } finally {
    clearSessionCookie(res);
    res.json({ ok: true });
  }
});

app.get('/api/listings', async (_req, res) => {
  try {
    const result = await pool.query(`
      SELECT l.id, l.title, l.price, l.status, l.created_at, u.email AS seller_email
      FROM listings l JOIN users u ON u.id = l.seller_id
      WHERE l.status = 'active' ORDER BY l.created_at DESC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Listings error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/listings', auth, requireCsrf, writeLimiter, requireRole('seller', 'admin'), async (req, res) => {
  try {
    const title = String(req.body?.title || '').trim().slice(0, 160);
    const price = Number(req.body?.price);
    if (!title || !Number.isFinite(price) || price <= 0 || price > 10000000) {
      return res.status(400).json({ error: 'valid title and price required' });
    }
    const result = await pool.query(
      `INSERT INTO listings(seller_id, title, price) VALUES($1, $2, $3)
       RETURNING id, seller_id, title, price, status, created_at`,
      [req.user.id, title, price]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create listing error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.get('/api/orders', auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT o.id, o.listing_id, o.buyer_id, o.status, o.created_at,
             l.title, l.price, l.seller_id, u.email AS seller_email
      FROM orders o JOIN listings l ON l.id = o.listing_id JOIN users u ON u.id = l.seller_id
      WHERE o.buyer_id = $1 OR l.seller_id = $1 ORDER BY o.created_at DESC
    `, [req.user.id]);
    res.json(result.rows);
  } catch (error) {
    console.error('Orders error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/orders', auth, requireCsrf, writeLimiter, async (req, res) => {
  const client = await pool.connect();
  try {
    const listingId = Number(req.body?.listing_id);
    if (!Number.isInteger(listingId) || listingId <= 0) return res.status(400).json({ error: 'valid listing_id required' });

    await client.query('BEGIN');
    const listing = await client.query(
      `SELECT id, seller_id FROM listings WHERE id = $1 AND status = 'active' FOR UPDATE`,
      [listingId]
    );
    if (!listing.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'listing not found or not active' });
    }
    if (String(listing.rows[0].seller_id) === String(req.user.id)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'cannot buy your own listing' });
    }

    const result = await client.query(
      `INSERT INTO orders(listing_id, buyer_id) VALUES($1, $2)
       RETURNING id, listing_id, buyer_id, status, created_at`,
      [listingId, req.user.id]
    );
    await client.query('COMMIT');
    res.status(201).json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    if (error.code === '23505') return res.status(409).json({ error: 'listing already has an active order' });
    console.error('Create order error:', error);
    res.status(500).json({ error: 'server error' });
  } finally {
    client.release();
  }
});

app.patch('/api/orders/:id/status', auth, requireCsrf, writeLimiter, async (req, res) => {
  const allowed = new Set(['pending', 'paid', 'completed', 'cancelled']);
  const status = String(req.body?.status || '');
  const orderId = Number(req.params.id);
  if (!Number.isInteger(orderId) || !allowed.has(status)) return res.status(400).json({ error: 'invalid order or status' });
  try {
    const check = await pool.query(
      `SELECT o.id, o.status AS current_status, o.buyer_id, l.seller_id
       FROM orders o JOIN listings l ON l.id = o.listing_id WHERE o.id = $1`,
      [orderId]
    );
    if (!check.rowCount) return res.status(404).json({ error: 'order not found' });
    const row = check.rows[0];
    const isSeller = String(row.seller_id) === String(req.user.id);
    const isBuyer = String(row.buyer_id) === String(req.user.id);
    const isAdmin = req.user.role === 'admin';
    if (!isSeller && !isBuyer && !isAdmin) return res.status(403).json({ error: 'forbidden' });
    if (status === 'paid' && !isAdmin) return res.status(403).json({ error: 'payment must be confirmed by payment service' });
    if (status === 'completed' && !isAdmin && !(isSeller && row.current_status === 'paid')) return res.status(409).json({ error: 'order must be paid before completion' });
    if (status === 'cancelled' && !['pending', 'paid'].includes(row.current_status)) return res.status(409).json({ error: 'order cannot be cancelled in current status' });

    const result = await pool.query(
      `UPDATE orders SET status = $1 WHERE id = $2
       RETURNING id, listing_id, buyer_id, status, created_at`,
      [status, orderId]
    );
    if (status === 'completed') {
      await pool.query(`UPDATE listings SET status = 'sold' WHERE id = $1`, [result.rows[0].listing_id]);
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update order error:', error);
    res.status(500).json({ error: 'server error' });
  }
});

app.use((err, _req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'server error' });
});

async function start() {
  await initDatabase();
  const server = app.listen(PORT, () => console.log(`eFootball Market API listening on port ${PORT}`));
  const shutdown = async () => server.close(async () => { await pool.end(); process.exit(0); });
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

start().catch((error) => {
  console.error('Startup failed:', error);
  process.exit(1);
});
